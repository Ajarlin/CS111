public class HotelRoom
{
	final String singleRoom    = "single";
	final String doubleRoom    = "double";
	final String businessSuite = "business";


	// define your fields here


	public HotelRoom(String guestname, String roomtype, int days)
	{
		// complete this method
	}

	public String getGuestName()
	{
		return null; // replace this line with your code
	}

	public String getRoomType()
	{
		return null; // replace this line with your code
	}

	public int getReservationLength()
	{
		return 0; // replace this line with your code
	}
    
	public double getEstimatedPrice()
	{
		return 0.00; // replace this line with your code
	}

	public void setRoomType(String roomtype)
	{
		// complete this method
	}

	public void setReservationLength(int days)
	{
		// complete this method
	}

	public double getActualPrice(int daysStayed)
	{
		return 0.00; // replace this line with your code
	}

}
