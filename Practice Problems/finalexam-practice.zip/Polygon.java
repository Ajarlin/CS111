public class Polygon
{
	// define fields here

	public Polygon(int numvertices)
	{
		// complete this method
	}

	public boolean setVertex(int vertexnumber, Point p)
	{
		return false; // replace this line with your code
	}

	public double getPerimeter()
	{
		return 0.0; // replace this line with your code
	}

	public double getArea()
	{
		return 0.0; // replace this line with your code
	}
}
